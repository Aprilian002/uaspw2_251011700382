<?php
session_start();

// Memastikan user sudah login sebelum mencetak laporan
if(!isset($_SESSION['login'])){
    header("Location: ../login.php");
    exit;
}

include "../config/koneksi.php";

// Query mengambil semua data koleksi e-book dari database
$query = mysqli_query($koneksi, "SELECT * FROM ebooks ORDER BY id DESC");

// Fungsi pembantu untuk memformat tanggal YYYY-MM-DD menjadi format Indonesia
function tgl_indo($tanggal){
    $bulan = array (
        1 =>   'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    );
    $pecahkan = explode('-', $tanggal);
    return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Koleksi E-Book - Aplikasi Digital</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #fff;
            color: #000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .header-laporan {
            border-bottom: 3px double #000;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        .table th {
            background-color: #f8f9fa !important;
            color: #000 !important;
            text-align: center;
        }
        .no-print-area {
            background-color: #f1f3f5;
            border-bottom: 1px solid #dee2e6;
        }
        
        /* Pengaturan Khusus Mode Cetak (Kertas/PDF) */
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                padding: 0;
                margin: 0;
            }
            .container {
                max-width: 100% !important;
                width: 100% !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }
    </style>
</head>
<body>

<!-- BAR ATAS (TIDAK IKUT TERCETAK) -->
<div class="no-print no-print-area p-3 mb-4">
    <div class="container d-flex justify-content-between align-items-center">
        <div>
            <a href="index.php" class="btn btn-secondary btn-sm px-3">
                <i class="fa-solid fa-arrow-left me-2"></i>Kembali ke Menu Laporan
            </a>
        </div>
        <div>
            <button onclick="window.print()" class="btn btn-success btn-sm px-4 fw-bold">
                <i class="fa-solid fa-print me-2"></i>Cetak Sekarang / Simpan PDF
            </button>
        </div>
    </div>
</div>

<div class="container">

    <!-- KOP SURAT LAPORAN (DIGITAL LIBRARY) -->
    <div class="header-laporan text-center">
        <h2 class="fw-bold text-uppercase m-0" style="letter-spacing: 1px;">PERPUSTAKAAN DIGITAL NUSANTARA</h2>
        <p class="m-0 text-muted" style="font-size: 0.9rem;">Kompleks Pendidikan Siber, Gedung Digital Lt. 3, Jakarta</p>
        <p class="m-0 text-muted" style="font-size: 0.9rem;">Telp: (021) 555-2026 | Email: support@ebookdigital.com</p>
    </div>

    <div class="text-center mb-4">
        <h4 class="fw-bold m-1 text-uppercase">Laporan Rekapitulasi Data Koleksi E-Book</h4>
        <small class="text-secondary">Sistem Pengelolaan Data E-Book</small>
    </div>

    <!-- TABEL DATA UTAMA -->
    <div class="table-responsive">
        <table class="table table-bordered align-middle">
            <thead class="table-light">
                <tr>
                    <th width="5%">No</th>
                    <th width="12%">Cover</th>
                    <th>Judul E-Book</th>
                    <th width="18%">Penulis</th>
                    <th width="18%">Penerbit</th>
                    <th width="12%">Tahun Terbit</th>
                    <th width="15%">Kategori</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                $total_buku = mysqli_num_rows($query);
                
                if($total_buku > 0) {
                    while($row = mysqli_fetch_assoc($query)){
                ?>
                <tr>
                    <td class="text-center text-secondary"><?= $no++; ?></td>
                    <td class="text-center">
                        <img src="../assets/upload/<?= $row['cover']; ?>" onerror="this.src='https://placehold.co/50x70?text=No+Cover';" class="rounded border" width="50" height="70" style="object-fit: cover;" alt="Cover">
                    </td>
                    <td class="fw-bold text-dark"><?= htmlspecialchars($row['judul']); ?></td>
                    <td><?= htmlspecialchars($row['penulis']); ?></td>
                    <td><?= htmlspecialchars($row['penerbit']); ?></td>
                    <td class="text-center"><?= htmlspecialchars($row['tahun_terbit']); ?></td>
                    <td class="text-center"><span class="badge bg-secondary text-white"><?= htmlspecialchars($row['kategori'] ?? 'Umum'); ?></span></td>
                </tr>
                <?php 
                    }
                } else {
                ?>
                <tr>
                    <td colspan="7" class="text-center py-4 text-muted">
                        <i class="fa-solid fa-folder-open d-block fs-3 mb-2"></i>
                        Belum ada data koleksi e-book yang tersimpan di sistem.
                    </td>
                </tr>
                <?php } ?>
                
                <tr class="table-light">
                    <th colspan="6" class="text-end py-3 fw-bold text-uppercase">Total Keseluruhan Koleksi Buku :</th>
                    <th class="text-center py-3 text-primary fw-bold fs-5">
                        <?= $total_buku; ?> Judul
                    </th>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- TANDA TANGAN (SIGNATURE) -->
    <div class="row mt-5 pt-4">
        <div class="col-md-4 offset-md-8 text-center">
            <p class="mb-0">Jakarta, <?= tgl_indo(date('Y-m-d')); ?></p>
            <p class="fw-bold mb-5 pb-3">Kepala Pustakawan Digital,</p>
            <p class="mb-0 border-bottom d-inline-block fw-bold px-4" style="min-width: 180px;">( .................................... )</p>
        </div>
    </div>

</div>

</body>
</html>