<?php
session_start();

// Proteksi keamanan: pastikan user sudah login sebelum mengakses menu laporan
if(!isset($_SESSION['login'])){
    header("Location: ../login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - E-Book Digital</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
        }

        /* Layout Sidebar */
        .wrapper {
            display: flex;
            align-items: stretch;
            min-height: 100vh;
        }

        #sidebar {
            min-width: 260px;
            max-width: 260px;
            background-color: #2c3e50;
            color: #fff;
            transition: all 0.3s;
        }

        #sidebar .sidebar-header {
            padding: 20px;
            background-color: #1a252f;
            text-align: center;
        }

        #sidebar .user-panel {
            padding: 15px;
            border-bottom: 1px solid #34495e;
            text-align: center;
        }

        #sidebar ul a {
            padding: 12px 20px;
            font-size: 1.1em;
            display: block;
            color: #d1d8e0;
            text-decoration: none;
            transition: all 0.3s;
        }

        #sidebar ul a:hover {
            color: #fff;
            background: #34495e;
            padding-left: 25px;
        }

        #sidebar ul a.active {
            color: #fff;
            background: #3498db;
            font-weight: bold;
        }

        /* Area Konten Utama */
        #content {
            width: 100%;
            padding: 20px;
            min-height: 100vh;
        }

        .navbar-custom {
            background-color: #3498db;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .card-custom {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            max-width: 800px;
        }
    </style>
</head>
<body>

<div class="wrapper">
    
    <!-- SIDEBAR NAVIGATION -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h4 class="m-0 fw-bold"><i class="fa-solid fa-book-open me-2"></i>E-BOOK DIGITAL</h4>
        </div>

        <div class="user-panel">
            <div class="mb-2">
                <img src="https://www.w3schools.com/howto/img_avatar.png" class="rounded-circle" width="60" alt="User Avatar">
            </div>
            <small class="d-block fw-bold"><?= htmlspecialchars($_SESSION['nama'] ?? 'Administrator'); ?></small>
            <small class="text-success"><i class="fa-solid fa-circle fa-xs me-1"></i> Online</small>
        </div>

        <ul class="list-unstyled components mt-3">
            <p class="text-muted px-4 mb-2" style="font-size: 0.8rem; letter-spacing: 1px;">MAIN NAVIGATION</p>
            <li>
                <a href="../dashboard.php"><i class="fa-solid fa-gauge me-3"></i>DASHBOARD</a>
            </li>
            <li>
                <a href="../produk/index.php"><i class="fa-solid fa-book me-3"></i>DATA E-BOOK</a>
            </li>
            <li>
                <a href="index.php" class="active"><i class="fa-solid fa-file-pdf me-3"></i>CETAK LAPORAN</a>
            </li>
            <li>
                <a href="../logout.php" onclick="return confirm('Yakin ingin logout?')"><i class="fa-solid fa-right-from-bracket me-3"></i>LOGOUT</a>
            </li>
        </ul>
    </nav>

    <!-- CONTENT AREA -->
    <div id="content">
        
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom rounded-3 mb-4 px-3">
            <div class="container-fluid">
                <span class="navbar-brand mb-0 h1 fs-6">Sistem Pengelolaan Data E-Book</span>
            </div>
        </nav>

        <div class="container-fluid">
            
            <div class="mb-4">
                <h3 class="m-0 fw-bold" style="color: #2d3748;">Menu Cetak Laporan</h3>
                <small class="text-muted">Cetak dokumen fisik atau ekspor laporan rekapitulasi data entri ke format PDF</small>
            </div>

            <div class="card card-custom bg-white p-5 text-center mx-auto mt-4">
                <div class="mb-4">
                    <i class="fa-solid fa-file-pdf text-danger animate__animated animate__pulse animate__infinite" style="font-size: 5rem;"></i>
                </div>
                
                <h4 class="fw-bold text-dark mb-2">Laporan Rekapitulasi Koleksi E-Book</h4>
                <p class="text-muted mb-4 mx-auto" style="max-width: 500px;">
                    Klik tombol di bawah untuk membuat laporan cetak PDF dari seluruh data koleksi e-book digital yang telah diinput ke dalam database sistem.
                </p>
                
                <div class="d-flex justify-content-center gap-3 border-top pt-4">
                    <!-- LINK AKSES KE FILE cetak.php YANG BARU -->
                    <a href="cetak.php" target="_blank" class="btn btn-danger btn-lg px-4 fw-bold shadow-sm" style="border-radius: 8px;">
                        <i class="fa-solid fa-print me-2"></i>Cetak & Simpan Ke PDF
                    </a>
                    <a href="../produk/index.php" class="btn btn-light border btn-lg px-4 text-secondary" style="border-radius: 8px;">
                        Kembali Ke Tabel Data
                    </a>
                </div>
            </div>

        </div>
    </div>

</div>

</body>
</html>