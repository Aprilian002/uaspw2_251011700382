<?php
// Mengubah koneksi database ke nama database sesuai NIM kamu
$koneksi = mysqli_connect("localhost", "root", "", "uas_251011700382");

if (mysqli_connect_errno()) {
    echo "Koneksi database gagal: " . mysqli_connect_error();
}
?>