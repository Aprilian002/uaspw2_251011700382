<?php
session_start();
// Menghubungkan ke konfigurasi database uas_nim
include 'config/koneksi.php';

$username = $_POST['username'];
// Menggunakan MD5 untuk enkripsi password sesuai bawaan codingan lamamu
$password = md5($_POST['password']);

// Menyesuaikan query ke tabel 'users' sesuai rancangan database baru
$query = mysqli_query(
    $koneksi,
    "SELECT * FROM users 
    WHERE username='$username' 
    AND password='$password'"
);

$data = mysqli_fetch_assoc($query);

if($data){
    $_SESSION['login'] = true;
    // Menggunakan kolom username sebagai penanda nama login
    $_SESSION['nama'] = $data['username'];

    header("Location: dashboard.php");
}else{
    header("Location: login.php?pesan=gagal");
}
?>