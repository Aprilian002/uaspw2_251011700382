<?php
session_start();

if(!isset($_SESSION['login'])){
    header("Location: ../login.php");
    exit;
}

include "../config/koneksi.php";

// Proses Simpan Data jika form disubmit
if (isset($_POST['simpan'])) {
    $judul        = mysqli_real_escape_string($koneksi, $_POST['judul']);
    $penulis      = mysqli_real_escape_string($koneksi, $_POST['penulis']);
    $penerbit     = mysqli_real_escape_string($koneksi, $_POST['penerbit']);
    $tahun_terbit = mysqli_real_escape_string($koneksi, $_POST['tahun_terbit']);
    $kategori     = mysqli_real_escape_string($koneksi, $_POST['kategori']);
    
    $cover_ebook = ""; 

    if(isset($_FILES['cover']['name']) && $_FILES['cover']['name'] != "") {
        $filename = $_FILES['cover']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $allowed = ['png', 'jpg', 'jpeg'];
        
        if(in_array(strtolower($ext), $allowed)) {
            $cover_ebook = time() . '_' . $filename;
            // Memastikan file gambar masuk ke direktori yang benar
            move_uploaded_file($_FILES['cover']['tmp_name'], '../assets/upload/' . $cover_ebook);
        }
    }

    // QUERY INSERT: Menyesuaikan dengan kolom tabel database 'ebooks'
    $query = "INSERT INTO ebooks (judul, penulis, penerbit, tahun_terbit, kategori, cover) 
              VALUES ('$judul', '$penulis', '$penerbit', '$tahun_terbit', '$kategori', '$cover_ebook')";

    $insert = mysqli_query($koneksi, $query);

    if ($insert) {
        echo "<script>
                alert('Data Koleksi E-Book Berhasil Ditambahkan!');
                window.location.href = 'index.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal menambahkan data e-book: " . mysqli_error($koneksi) . "');
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah E-Book - Aplikasi Digital</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', sans-serif; overflow-x: hidden; }
        .wrapper { display: flex; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background-color: #2c3e50; color: #fff; transition: all 0.3s; }
        #sidebar .sidebar-header { padding: 20px; background-color: #1a252f; text-align: center; }
        #sidebar .user-panel { padding: 15px; border-bottom: 1px solid #34495e; text-align: center; }
        #sidebar ul a { padding: 12px 20px; font-size: 1.1em; display: block; color: #d1d8e0; text-decoration: none; }
        #sidebar ul a.active { color: #fff; background: #3498db; font-weight: bold; }
        #content { width: 100%; padding: 20px; min-height: 100vh; flex: 1; }
        .navbar-custom { background-color: #3498db; }
        
        .card-custom {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            width: 100% !important; /* Paksa card memenuhi sisa layar ke kanan */
        }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR NAVIGATION -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h4 class="m-0 fw-bold"><i class="fa-solid fa-book-open me-2"></i>E-BOOK DIGITAL</h4>
        </div>
        <div class="user-panel">
            <div class="mb-2">
                <img src="https://www.w3schools.com/howto/img_avatar.png" class="rounded-circle" width="60" alt="User Avatar">
            </div>
            <small class="d-block fw-bold"><?= htmlspecialchars($_SESSION['nama'] ?? 'Administrator'); ?></small>
            <small class="text-success"><i class="fa-solid fa-circle fa-xs me-1"></i> Online</small>
        </div>
        <ul class="list-unstyled components mt-3">
            <p class="text-muted px-4 mb-2" style="font-size: 0.8rem; letter-spacing: 1px;">MAIN NAVIGATION</p>
            <li><a href="../dashboard.php"><i class="fa-solid fa-gauge me-3"></i>DASHBOARD</a></li>
            <li><a href="index.php" class="active"><i class="fa-solid fa-book me-3"></i>DATA E-BOOK</a></li>
            <li><a href="../laporan/index.php"><i class="fa-solid fa-file-pdf me-3"></i>CETAK LAPORAN</a></li>
            <li><a href="../logout.php" onclick="return confirm('Yakin ingin logout?')"><i class="fa-solid fa-right-from-bracket me-3"></i>LOGOUT</a></li>
        </ul>
    </nav>

    <!-- CONTENT AREA -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom rounded-3 mb-4 px-3">
            <div class="container-fluid">
                <span class="navbar-brand mb-0 h1 fs-6">Sistem Pengelolaan Data E-Book</span>
            </div>
        </nav>

        <!-- Diubah ke container-fluid agar melebar maksimal -->
        <div class="container-fluid">
            <div class="mb-4">
                <h3 class="m-0 fw-bold" style="color: #2d3748;">Tambah E-Book Baru</h3>
                <small class="text-muted">Masukkan spesifikasi materi dan unggah berkas sampul e-book</small>
            </div>

            <!-- SUDAH DIHAPUS max-width inline-nya agar otomatis mentok kanan -->
            <div class="card card-custom p-4">
                <form action="" method="POST" enctype="multipart/form-data">
                    
                    <!-- Dibuat berjajar 2 kolom menggunakan grid Bootstrap agar input tidak melar berlebihan saat layar lebar -->
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold text-secondary"><i class="fa-solid fa-book me-2"></i>Judul E-Book</label>
                            <input type="text" name="judul" class="form-control py-2" placeholder="Masukkan judul lengkap e-book" required>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold text-secondary"><i class="fa-solid fa-user-pen me-2"></i>Penulis / Pengarang</label>
                            <input type="text" name="penulis" class="form-control py-2" placeholder="Nama penulis buku" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold text-secondary"><i class="fa-solid fa-building-columns me-2"></i>Penerbit</label>
                        <input type="text" name="penerbit" class="form-control py-2" placeholder="Nama perusahaan penerbit" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold text-secondary"><i class="fa-solid fa-calendar-days me-2"></i>Tahun Terbit</label>
                            <input type="number" name="tahun_terbit" class="form-control py-2" placeholder="Contoh: 2024" min="1000" max="2100" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold text-secondary"><i class="fa-solid fa-tags me-2"></i>Kategori</label>
                            <input type="text" name="kategori" class="form-control py-2" placeholder="Contoh: Teknologi / Novel" required>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label fw-semibold text-secondary"><i class="fa-solid fa-image me-2"></i>File Sampul / Cover E-Book</label>
                        <input type="file" name="cover" class="form-control py-2" accept=".png, .jpg, .jpeg" required>
                        <small class="text-muted d-block mt-1">*Format gambar didukung: PNG, JPG, JPEG</small>
                    </div>

                    <div class="mt-4 pt-2 border-top">
                        <button type="submit" name="simpan" class="btn btn-success px-4 py-2 fw-semibold me-2" style="border-radius: 8px;">
                            <i class="fa-solid fa-floppy-disk me-2"></i>Simpan E-Book
                        </button>
                        <a href="index.php" class="btn btn-light border px-4 py-2 fw-semibold" style="border-radius: 8px;">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>