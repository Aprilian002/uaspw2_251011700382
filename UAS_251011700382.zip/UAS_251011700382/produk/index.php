<?php
session_start();

if(!isset($_SESSION['login'])){
    header("Location: ../login.php");
    exit;
}

include "../config/koneksi.php";

// Logika Pencarian Berdasarkan Judul, Kategori, atau Penulis E-Book
$keyword = "";
if (isset($_GET['cari'])) {
    $keyword = mysqli_real_escape_string($koneksi, $_GET['cari']);
    $query = "SELECT * FROM ebooks WHERE 
              judul LIKE '%$keyword%' OR 
              kategori LIKE '%$keyword%' OR
              penulis LIKE '%$keyword%'
              ORDER BY id DESC";
} else {
    $query = "SELECT * FROM ebooks ORDER BY id DESC";
}

$data_ebook = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data E-Book - Aplikasi Digital</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', sans-serif; overflow-x: hidden; }
        .wrapper { display: flex; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background-color: #2c3e50; color: #fff; transition: all 0.3s; }
        #sidebar .sidebar-header { padding: 20px; background-color: #1a252f; text-align: center; }
        #sidebar .user-panel { padding: 15px; border-bottom: 1px solid #34495e; text-align: center; }
        #sidebar ul a { padding: 12px 20px; font-size: 1.1em; display: block; color: #d1d8e0; text-decoration: none; }
        #sidebar ul a.active { color: #fff; background: #3498db; font-weight: bold; }
        #content { width: 100%; padding: 20px; min-height: 100vh; flex: 1; }
        .navbar-custom { background-color: #3498db; }
        
        /* Mengubah lebar card utama agar memanjang penuh mengikuti layar (Mentok Kanan) */
        .card-custom { 
            border: none; 
            border-radius: 15px; 
            box-shadow: 0 8px 24px rgba(0,0,0,0.04); 
            background-color: #ffffff; 
            width: 100% !important;
        }
    </style>
</head>
<body>

<div class="wrapper">
    <nav id="sidebar">
        <div class="sidebar-header">
            <h4 class="m-0 fw-bold"><i class="fa-solid fa-book-open me-2"></i>E-BOOK DIGITAL</h4>
        </div>
        <div class="user-panel">
            <div class="mb-2">
                <img src="https://www.w3schools.com/howto/img_avatar.png" class="rounded-circle" width="60" alt="User Avatar">
            </div>
            <small class="d-block fw-bold"><?= htmlspecialchars($_SESSION['nama'] ?? 'Administrator'); ?></small>
            <small class="text-success"><i class="fa-solid fa-circle fa-xs me-1"></i> Online</small>
        </div>
        <ul class="list-unstyled components mt-3">
            <p class="text-muted px-4 mb-2" style="font-size: 0.8rem; letter-spacing: 1px;">MAIN NAVIGATION</p>
            <li><a href="../dashboard.php"><i class="fa-solid fa-gauge me-3"></i>DASHBOARD</a></li>
            <li><a href="index.php" class="active"><i class="fa-solid fa-book me-3"></i>DATA E-BOOK</a></li>
            <li><a href="../laporan/index.php"><i class="fa-solid fa-file-pdf me-3"></i>CETAK LAPORAN</a></li>
            <li><a href="../logout.php" onclick="return confirm('Yakin ingin logout?')"><i class="fa-solid fa-right-from-bracket me-3"></i>LOGOUT</a></li>
        </ul>
    </nav>

    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom rounded-3 mb-4 px-3">
            <div class="container-fluid">
                <span class="navbar-brand mb-0 h1 fs-6">Sistem Pengelolaan Data E-Book</span>
            </div>
        </nav>

        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="m-0 fw-bold" style="color: #2d3748;">Data Koleksi E-Book</h3>
                    <small class="text-muted">Kelola persediaan materi e-book digital pada sistem</small>
                </div>
                
                <div class="d-flex gap-2">
                    <a href="../laporan/cetak.php" target="_blank" class="btn btn-danger fw-semibold" style="border-radius: 8px;">
                        <i class="fa-solid fa-file-pdf me-2"></i>Cetak Laporan PDF
                    </a>
                    <a href="tambah.php" class="btn btn-success fw-semibold" style="border-radius: 8px;">
                        <i class="fa-solid fa-plus me-2"></i>Tambah E-Book
                    </a>
                </div>
            </div>

            <div class="card card-custom p-4">
                
                <form action="" method="GET" class="mb-4">
                    <div class="row g-2">
                        <div class="col-md-5">
                            <div class="input-group">
                                <input type="text" name="cari" class="form-control" placeholder="Cari judul, penulis, atau kategori..." value="<?= htmlspecialchars($keyword); ?>" style="border-radius: 8px 0 0 8px;">
                                <button type="submit" class="btn btn-secondary" style="border-radius: 0 8px 8px 0;">
                                    <i class="fa-solid fa-magnifying-glass"></i>
                                </button>
                            </div>
                        </div>
                        <?php if(!empty($keyword)): ?>
                            <div class="col-md-2">
                                <a href="index.php" class="btn btn-light border text-danger w-100" style="border-radius: 8px;">
                                    <i class="fa-solid fa-circle-xmark me-2"></i>Reset
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th width="50">No</th>
                                <th width="80">Cover</th>
                                <th>Judul E-Book</th>
                                <th>Penulis</th>
                                <th>Penerbit</th>
                                <th width="120">Tahun Terbit</th>
                                <th>Kategori</th>
                                <th class="text-center" width="120">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $no = 1;
                            if(mysqli_num_rows($data_ebook) > 0) {
                                while($row = mysqli_fetch_assoc($data_ebook)) { 
                                    
                                    // LOGIKA DETEKSI SUMBER GAMBAR (STALESS/SVG ATAU FILE LOKAL)
                                    if (strpos($row['cover'], 'data:image') === 0) {
                                        $gambar_src = $row['cover'];
                                    } else {
                                        $gambar_src = "../assets/upload/" . $row['cover'];
                                    }
                            ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td>
                                    <img src="<?= $gambar_src; ?>" onerror="this.src='https://placehold.co/60x80?text=No+Cover';" class="rounded border shadow-sm" width="60" height="80" style="object-fit: cover;" alt="Cover">
                                </td>
                                <td class="fw-bold text-primary"><?= htmlspecialchars($row['judul']); ?></td>
                                <td><?= htmlspecialchars($row['penulis']); ?></td>
                                <td><?= htmlspecialchars($row['penerbit']); ?></td>
                                <td><?= htmlspecialchars($row['tahun_terbit']); ?></td>
                                <td><span class="badge bg-info text-dark"><?= htmlspecialchars($row['kategori'] ?? 'Umum'); ?></span></td>
                                <td class="text-center">
                                    <a href="edit.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm me-1" style="border-radius: 6px;" title="Edit Data">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                    </a>
                                    <a href="hapus.php?id=<?= $row['id']; ?>" onclick="return confirm('Yakin ingin menghapus data e-book ini?')" class="btn btn-danger btn-sm" style="border-radius: 6px;" title="Hapus Data">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php 
                                }
                            } else {
                                echo "<tr><td colspan='8' class='text-center text-muted py-4'>Data e-book tidak ditemukan untuk kata kunci \"<b>".htmlspecialchars($keyword)."</b>\"</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

</body>
</html>