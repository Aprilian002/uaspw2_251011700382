<?php
session_start();

if(!isset($_SESSION['login'])){
    header("Location: ../login.php");
    exit;
}

include "../config/koneksi.php";

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);

    // 1. Ambil data e-book terlebih dahulu untuk menghapus berkas cover-nya
    $data = mysqli_query($koneksi, "SELECT * FROM ebooks WHERE id='$id'");
    $row = mysqli_fetch_assoc($data);

    // Menggunakan try-catch untuk menangkap error foreign key jika data terikat riwayat lain
    try {
        // 2. Jalankan perintah hapus data di database dari tabel ebooks
        $query = "DELETE FROM ebooks WHERE id = '$id'";
        $hapus = mysqli_query($koneksi, $query);

        if ($hapus) {
            // 3. Jika data di database berhasil dihapus, baru hapus file fisik gambarnya
            if(!empty($row['cover']) && file_exists("../assets/upload/".$row['cover'])){
                unlink("../assets/upload/".$row['cover']);
            }

            echo "<script>
                    alert('Data Koleksi E-Book Berhasil Dihapus!');
                    window.location.href = 'index.php';
                  </script>";
            exit;
        }
    } catch (mysqli_sql_exception $e) {
        // Jika gagal dihapus karena batasan integritas referensial (foreign key)
        echo "<script>
                alert('Gagal Menghapus! Data e-book ini tidak bisa dihapus karena terikat dengan data atau riwayat aktif lainnya.');
                window.location.href = 'index.php';
              </script>";
        exit;
    }
} else {
    header("Location: index.php");
    exit;
}
?>