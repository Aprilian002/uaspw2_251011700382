<?php
session_start();

if(isset($_SESSION['login'])){
    header("Location: dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Aplikasi E-Book Digital</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            /* Mengubah latar belakang ke gambar perpustakaan/e-book yang estetik */
            background: url('https://images.unsplash.com/photo-1507842217343-583bb7270b66?q=80&w=1920') no-repeat center center fixed;
            background-size: cover;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
        }

        /* KUNCI EFEK GLASSMORPHISM (KACA BLUR) */
        .glass-card {
            background: rgba(255, 255, 255, 0.15); /* Warna putih sangat transparan */
            backdrop-filter: blur(10px); /* Membuat efek blur pada gambar di belakangnya */
            -webkit-backdrop-filter: blur(10px); /* Pendukung untuk Safari */
            border: 1px solid rgba(255, 255, 255, 0.25); /* Garis tepi tipis warna putih transparan */
            border-radius: 20px;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);
            color: #ffffff;
            width: 400px;
        }

        /* Kustomisasi Input Form agar Senada dengan Efek Kaca */
        .form-control-glass {
            background: rgba(255, 255, 255, 0.2) !important;
            border: 1px solid rgba(255, 255, 255, 0.3) !important;
            border-radius: 30px !important; /* Membuat input melengkung oval */
            color: #ffffff !important;
            padding-left: 20px;
            padding-right: 40px;
        }

        .form-control-glass::placeholder {
            color: rgba(255, 255, 255, 0.75);
        }

        .form-control-glass:focus {
            background: rgba(255, 255, 255, 0.25) !important;
            box-shadow: 0 0 8px rgba(255, 255, 255, 0.5) !important;
            border-color: rgba(255, 255, 255, 0.5) !important;
        }

        /* Pembungkus group input untuk menaruh ikon di kanan */
        .input-group-glass {
            position: relative;
        }

        .input-group-glass i {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.8);
            z-index: 5;
        }

        /* Tombol Login Putih Melengkung */
        .btn-login {
            background-color: #ffffff;
            color: #333333;
            font-weight: 600;
            border-radius: 30px;
            border: none;
            transition: all 0.3s;
        }

        .btn-login:hover {
            background-color: rgba(255, 255, 255, 0.85);
            transform: scale(1.02);
        }

        /* Link teks di bagian bawah */
        .glass-link {
            color: #ffffff;
            text-decoration: none;
            font-size: 0.9rem;
            opacity: 0.8;
        }
        .glass-link:hover {
            text-decoration: underline;
            opacity: 1;
        }
    </style>
</head>
<body>

<div class="glass-card p-4 mx-3">

    <h2 class="text-center fw-bold mb-2">Login</h2>
    <!-- Mengubah sub-title ke tema aplikasi E-Book -->
    <p class="text-center mb-4" style="color: rgba(255,255,255,0.8); font-size: 0.9rem;">Sistem Pengelolaan Data E-Book</p>

    <?php
    if(isset($_GET['pesan'])){
        echo "<div class='alert alert-danger py-2 text-center text-dark' style='border-radius:10px; font-size:0.9rem;'>Login Gagal! Akun salah.</div>";
    }
    ?>

    <form action="proses_login.php" method="POST">

        <div class="mb-3 input-group-glass">
            <input type="text"
                   name="username"
                   class="form-control form-control-glass"
                   placeholder="Username"
                   required>
            <i class="fa-solid fa-user"></i>
        </div>

        <div class="mb-3 input-group-glass">
            <input type="password"
                   name="password"
                   class="form-control form-control-glass"
                   placeholder="Password"
                   required>
            <i class="fa-solid fa-lock"></i>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-4 px-1" style="font-size: 0.85rem;">
            <div class="form-check m-0">
                <input class="form-check-input" type="checkbox" id="rememberMe" style="background-color: transparent; border-color: rgba(255,255,255,0.5);">
                <label class="form-check-label" for="rememberMe">Remember me</label>
            </div>
            <a href="#" class="glass-link"></a>
        </div>

        <button type="submit" class="btn btn-login w-100 py-2 mb-3">
            Login
        </button>

        <div class="text-center" style="font-size: 0.85rem;">
            <span> </span>
            <a href="#" class="fw-bold text-white text-decoration-none"></a>
        </div>

    </form>

</div>

</body>
</html>