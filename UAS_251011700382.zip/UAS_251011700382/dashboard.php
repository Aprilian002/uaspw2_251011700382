<?php
session_start();

// Proteksi halaman: Jika belum login, tendang kembali ke login.php
if(!isset($_SESSION['login'])){
    header("Location: login.php");
    exit;
}

include "config/koneksi.php";

// Mengambil jumlah total koleksi e-book di database untuk ditampilkan di counter box
$query_ebook = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM ebooks");
$data_ebook = mysqli_fetch_assoc($query_ebook);
$total_ebook = $data_ebook['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Aplikasi Digital E-Book</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', sans-serif; overflow-x: hidden; }
        .wrapper { display: flex; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background-color: #2c3e50; color: #fff; }
        #sidebar .sidebar-header { padding: 20px; background-color: #1a252f; text-align: center; }
        #sidebar .user-panel { padding: 15px; border-bottom: 1px solid #34495e; text-align: center; }
        #sidebar ul a { padding: 12px 20px; font-size: 1.1em; display: block; color: #d1d8e0; text-decoration: none; }
        #sidebar ul a.active { color: #fff; background: #3498db; font-weight: bold; }
        #content { width: 100%; padding: 20px; min-height: 100vh; }
        .navbar-custom { background-color: #3498db; }
        .card-custom { border: none; border-radius: 15px; box-shadow: 0 8px 24px rgba(0,0,0,0.04); background-color: #ffffff; }
        
        /* Desain Box Counter Status */
        .stat-card {
            border: none;
            border-radius: 15px;
            color: white;
            padding: 25px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 6px 20px rgba(0,0,0,0.08);
        }
        .stat-card .icon-bg {
            position: absolute;
            right: -15px;
            bottom: -15px;
            font-size: 6rem;
            opacity: 0.15;
        }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR NAVIGATION -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <h4 class="m-0 fw-bold"><i class="fa-solid fa-book-open me-2"></i>E-BOOK DIGITAL</h4>
        </div>
        <div class="user-panel">
            <div class="mb-2">
                <img src="https://www.w3schools.com/howto/img_avatar.png" class="rounded-circle" width="60" alt="User Avatar">
            </div>
            <small class="d-block fw-bold"><?= htmlspecialchars($_SESSION['nama'] ?? 'Administrator'); ?></small>
            <small class="text-success"><i class="fa-solid fa-circle fa-xs me-1"></i> Online</small>
        </div>
        <ul class="list-unstyled components mt-3">
            <p class="text-muted px-4 mb-2" style="font-size: 0.8rem; letter-spacing: 1px;">MAIN NAVIGATION</p>
            <li><a href="dashboard.php" class="active"><i class="fa-solid fa-gauge me-3"></i>DASHBOARD</a></li>
            <!-- Mengarahkan ke sub-folder produk/index.php -->
            <li><a href="produk/index.php"><i class="fa-solid fa-book me-3"></i>DATA E-BOOK</a></li>
            <li><a href="laporan/index.php"><i class="fa-solid fa-file-pdf me-3"></i>CETAK LAPORAN</a></li>
            <li><a href="logout.php" onclick="return confirm('Yakin ingin logout?')"><i class="fa-solid fa-right-from-bracket me-3"></i>LOGOUT</a></li>
        </ul>
    </nav>

    <!-- MAIN CONTENT -->
    <div id="content">
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom rounded-3 mb-4 px-3">
            <span class="navbar-brand mb-0 h1 fs-6">Sistem Pengelolaan Data E-Book</span>
        </nav>

        <div class="container-fluid">
            <div class="mb-4">
                <h3 class="m-0 fw-bold" style="color: #2d3748;">Dashboard Utama</h3>
                <small class="text-muted">Selamat datang kembali, <b><?= htmlspecialchars($_SESSION['nama'] ?? 'Admin'); ?></b>! Berikut ringkasan sistem hari ini.</small>
            </div>

            <!-- RANGKUMAN STATISTIK DATA -->
            <div class="row g-4 mb-4">
                <!-- Card Total Koleksi E-Book -->
                <div class="col-md-4">
                    <div class="stat-card bg-primary">
                        <h5>Total Koleksi E-Book</h5>
                        <h2 class="fw-bold my-2"><?= $total_ebook; ?> <span style="font-size: 1.2rem; font-weight: normal;">Judul</span></h2>
                        <p class="m-0" style="font-size: 0.85rem; opacity: 0.9;">Telah tersimpan di dalam database</p>
                        <i class="fa-solid fa-book icon-bg"></i>
                    </div>
                </div>

                <!-- Card Informasi Sistem -->
                <div class="col-md-4">
                    <div class="stat-card bg-success">
                        <h5>Status Server</h5>
                        <h2 class="fw-bold my-2">Aktif / Normal</h2>
                        <p class="m-0" style="font-size: 0.85rem; opacity: 0.9;">Koneksi Database Berjalan Lancar</p>
                        <i class="fa-solid fa-server icon-bg"></i>
                    </div>
                </div>

                <!-- Card Akses Cetak Laporan -->
                <div class="col-md-4">
                    <div class="stat-card bg-warning">
                        <h5>Laporan PDF</h5>
                        <h2 class="fw-bold my-2">Siap Cetak</h2>
                        <p class="m-0" style="font-size: 0.85rem; opacity: 0.9;">Laporan Data Inventaris Buku</p>
                        <i class="fa-solid fa-file-pdf icon-bg"></i>
                    </div>
                </div>
            </div>

            <!-- CARD JUMBOTRON SELAMAT DATANG -->
            <div class="card card-custom p-5 text-center bg-white">
                <div class="mx-auto mb-3 text-primary" style="font-size: 3.5rem;">
                    <i class="fa-solid fa-graduation-cap"></i>
                </div>
                <h2 class="fw-bold text-dark">Aplikasi Manajemen E-Book Perpustakaan Digital</h2>
                <p class="text-muted mx-auto col-md-8 mt-2">
                    Sistem ini dirancang khusus untuk mempermudah pustakawan dan pengelola dalam memonitor, menambah, menyunting, serta menghapus data arsip buku elektronik (*E-Book*) secara cepat dan efisien.
                </p>
                <div class="mt-4">
                    <a href="produk/index.php" class="btn btn-primary px-4 py-2 fw-semibold" style="border-radius: 8px;">
                        <i class="fa-solid fa-magnifying-glass-chart me-2"></i>Mulai Kelola Data E-Book
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

</body>
</html>